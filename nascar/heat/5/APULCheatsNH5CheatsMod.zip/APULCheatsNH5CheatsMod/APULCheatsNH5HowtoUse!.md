NASCAR Heat 5 cheats mod
==========================

by APUL Cheats

Installation:
---------------

1. Install the 64-bit version of BepInEx into your NASCAR Heat 5 folder according to these instructions, including the first run to generate the folder structure and config files: https://docs.bepinex.dev/articles/user_guide/installation/index.html
2. Drop KopachrisNH5CheatsMod.dll into the new BepInEx\plugins folder


Usage:
--------

In career mode, go to the "About Me" page and edit your driver. Change your driver's first and/or last name so that the cheat is present when the first and last name are added together. For example, to use the cheat 'rosebud', all of these names would be valid: Rosebud Chris, Chris Rosebud, Rose Bud, etc. The cheat will be activated whenever the character editor is exited while your name fits the cheat code.


Cheats:
---------

rosebud - adds $100,000
sugardaddy - adds $1,000,000
loanshark - removes $100,000
bigdebt - removes $1,000,000
donaldtrump - go bankrupt, removes ALL your money!
johnwardley - adds 10,000 fans. Wow!